#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <cstring>
#include <algorithm>
#define INF 1987654321
using namespace std;

ifstream fcin("mst.inp");
ofstream fcout("mst.out");
struct Edge { int u, v, w; };
int cache[10001];
int weight[10001];
int cnt[10001];
priority_queue<Edge> edge;
int n, m;
int u, v, w;

bool operator<(const Edge &A, const Edge &B) { return A.w > B.w; };
int find_kruskal(int n)
{
	if (cache[n] <= -1) return n;
	return cache[n] = find_kruskal(cache[n]);
}
void union_kruskal(int u, int v, int w)
{
	int l = find_kruskal(u);
	int r = find_kruskal(v);
	cache[r] += cache[l];
	cache[l] = r;
	weight[r] += weight[l] + w;
	weight[l] = 0;
}
void solve_kruskal()
{
	while (!edge.empty())
	{
		Edge temp = edge.top();
		edge.pop();

		if (find_kruskal(temp.u) == find_kruskal(temp.v))
			continue;
		union_kruskal(temp.u, temp.v, temp.w);
	}
	vector<pair<int, int> > ans;
	for (int i = 0; i < n; i++)
		if (cache[i] <= -1)
			ans.push_back(make_pair(-cache[i], weight[i]));
	sort(ans.begin(), ans.end());
	for (int i = 0; i < ans.size(); i++)
		fcout << ans[i].first << " " << ans[i].second << "\n";
}
int main()
{
	memset(cache, -1, sizeof(cache));
	fcin >> n >> m;
	for (int i = 0; i < m; i++)
	{
		fcin >> u >> v >> w;
		edge.push({ u,v,w });
	}
	solve_kruskal();
	return 0;
}