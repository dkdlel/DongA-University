#include <vector>
#include <fstream>
#include <queue>
#include <algorithm>
#include <iostream>
using namespace std;

struct Edge { int v, w; };
ifstream inp("mst.inp");
ofstream out("mst.out");
vector<vector<Edge> > edge;
vector<int> visited;
vector<pair<int,int> > ans_print;
bool operator<(const Edge &A, const Edge &B) { return A.w > B.w; };
int main()
{
	int n, m;
	inp >> n >> m;
	edge.resize(n);
	visited.resize(n);
	for (int i = 0; i < m; i++)
	{
		int u, v, w;
		inp >> u >> v >> w;
		edge[u].push_back({ v,w });
		edge[v].push_back({ u,w });
	}
	/* prim algorithm */
	for (int i = 0; i < n; i++)
	{
		if (visited[i]) continue;
		priority_queue<Edge> pq;
		pq.push({ i,0 });

		int ans_count = 0, ans_weight_sum = 0;
		while (!pq.empty())
		{
			Edge e = pq.top();
			int cur = e.v;
			int w = e.w;
			pq.pop();

			if (visited[cur]) continue;
			visited[cur] = 1;

			++ans_count;
			ans_weight_sum += w;
			for (int next = 0; next < edge[cur].size(); next++) // v���� ������ִ� �����鿡 ���Ͽ� pq.push
			{
				if (!visited[edge[cur][next].v])
					pq.push({ edge[cur][next].v,edge[cur][next].w });
			}
		}
		ans_print.push_back({ans_count, ans_weight_sum});
	}
	sort(ans_print.begin(), ans_print.end());
	for (int i = 0; i < ans_print.size(); i++)
		out << ans_print[i].first << " " << ans_print[i].second << "\n";
}